function Global.StartShapeTestCapsule(x1, y1, z1, x2, y2, z2, radius, flags, entity, p9)
	return _in(0x28579D1B8F8AAC80, x1, y1, z1, x2, y2, z2, radius, flags, entity, p9, _r, _ri)
end
