function Global.IsPlayerTargettingEntity(player, entity)
	return _in(0x7912F7FC4F6264B6, player, entity, _r)
end
