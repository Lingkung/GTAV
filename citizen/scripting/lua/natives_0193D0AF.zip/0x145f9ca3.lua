function Global.IsVehicleShopResprayAllowed(vehicle)
	return _in(0x8D474C8FAEFF6CDE, vehicle, _r)
end
