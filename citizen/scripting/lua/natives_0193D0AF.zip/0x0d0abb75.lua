function Global.IsEntityOnScreen(entity)
	return _in(0xE659E47AF827484B, entity, _r)
end
