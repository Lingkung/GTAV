function Global.N_0xa7a1127490312c36(p0)
	return _in(0xA7A1127490312C36, p0)
end
