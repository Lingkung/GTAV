function Global.N_0x694e00132f2823ed(entity, p1)
	return _in(0x694E00132F2823ED, entity, p1)
end
