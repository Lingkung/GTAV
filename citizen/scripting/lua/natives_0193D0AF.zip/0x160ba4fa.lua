function Global.N_0xb055a34527cb8fd7(vehicle, p1)
	return _in(0xB055A34527CB8FD7, vehicle, p1)
end
