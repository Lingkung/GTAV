function Global.IsPlayerVehicleRadioEnabled()
	return _in(0x5F43D83FD6738741, _r)
end
