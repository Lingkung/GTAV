function Global.N_0xe6a9f00d4240b519(p0, p1)
	return _in(0xE6A9F00D4240B519, p0, p1)
end
