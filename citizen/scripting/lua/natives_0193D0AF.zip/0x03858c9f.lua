function Global.CreateIncident(incidentType, x, y, z, p5, radius, outIncidentID)
	return _in(0x3F892CAF67444AE7, incidentType, x, y, z, p5, radius, _ii(outIncidentID) --[[ may be optional ]], _r)
end
