function Global.N_0xd801cc02177fa3f1()
	return _in(0xD801CC02177FA3F1)
end
