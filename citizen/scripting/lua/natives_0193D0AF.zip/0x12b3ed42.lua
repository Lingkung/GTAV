function Global.ClearPedAlternateWalkAnim(ped, p1)
	return _in(0x8844BBFCE30AA9E9, ped, p1)
end
