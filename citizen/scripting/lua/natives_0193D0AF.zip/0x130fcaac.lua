function Global.SetNightvision(toggle)
	return _in(0x18F621F7A5B1F85D, toggle)
end
