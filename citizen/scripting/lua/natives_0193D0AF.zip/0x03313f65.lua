function Global.N_0x55384438fc55ad8e(value)
	return _in(0x55384438FC55AD8E, value)
end
