function Global.TaskHeliChase(pilot, entityToFollow, x, y, z)
	return _in(0xAC83B1DB38D0ADA0, pilot, entityToFollow, x, y, z)
end
