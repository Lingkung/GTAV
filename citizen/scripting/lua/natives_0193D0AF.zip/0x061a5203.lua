function Global.NetworkGetDestroyerOfNetworkId(netId, weaponHash)
	return _in(0x7A1ADEEF01740A24, netId, _ii(weaponHash) --[[ may be optional ]], _r, _ri)
end
