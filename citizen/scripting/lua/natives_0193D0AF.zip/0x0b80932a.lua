function Global.N_0x700569dba175a77c(p0)
	return _in(0x700569DBA175A77C, p0, _r, _ri)
end
