function Global.N_0x81cbae94390f9f89()
	return _in(0x81CBAE94390F9F89)
end
