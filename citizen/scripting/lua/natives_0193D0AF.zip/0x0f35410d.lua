function Global.N_0x621c6e4729388e41(ped)
	return _in(0x621C6E4729388E41, ped, _r)
end
