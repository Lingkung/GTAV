function Global.RegisterFloatToSave(name)
	return _in(0x7CAEC29ECB5DFEBB, _i, _ts(name))
end
