function Global.DisablePhoneThisFrame(toggle)
	return _in(0x015C49A93E3E086E, toggle)
end
