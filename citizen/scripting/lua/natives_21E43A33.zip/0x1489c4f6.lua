function Global.DeleteChildRope(rope)
	return _in(0xAA5D6B1888E4DB20, rope, _r, _ri)
end
