function Global.ResetSpecialAbilityControlsCinematic(player, p1, p2)
	return _in(0xA0696A65F009EE18, player, p1, p2)
end
