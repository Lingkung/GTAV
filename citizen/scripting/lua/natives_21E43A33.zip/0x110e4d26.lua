function Global.N_0x9304881d6f6537ea(p0)
	return _in(0x9304881D6F6537EA, p0)
end
