function Global.IsPauseMenuActive()
	return _in(0xB0034A223497FFCB, _r)
end
