function Global.StopSaveStruct()
	return _in(0xEB1774DF12BB9F12)
end
