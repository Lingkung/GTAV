function Global.StatSetLicensePlate(statName, str)
	return _in(0x69FF13266D7296DA, _ch(statName), _ts(str), _r)
end
