function Global.GetMaxRangeOfCurrentPedWeapon(ped)
	return _in(0x814C9D19DFD69679, ped, _r, _rf)
end
