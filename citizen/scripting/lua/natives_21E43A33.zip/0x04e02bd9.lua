function Global.N_0x4c2330e61d3deb56(p0)
	return _in(0x4C2330E61D3DEB56, p0, _r, _ri)
end
