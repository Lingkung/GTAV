function Global.N_0x694e00132f2823ed(p0, p1)
	return _in(0x694E00132F2823ED, p0, p1)
end
