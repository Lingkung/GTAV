function Global.N_0xc01e93fac20c3346(p0)
	return _in(0xC01E93FAC20C3346, p0, _r)
end
