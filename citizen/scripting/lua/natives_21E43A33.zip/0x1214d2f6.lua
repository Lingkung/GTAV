function Global.N_0xbe3e347a87aceb82(p0, p1, p2, p3)
	return _in(0xBE3E347A87ACEB82, p0, p1, p2, p3, _r)
end
