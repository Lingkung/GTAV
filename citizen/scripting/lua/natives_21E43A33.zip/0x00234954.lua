function Global.N_0x820e9892a77e97cd(p0, p1)
	return _in(0x820E9892A77E97CD, p0, p1)
end
