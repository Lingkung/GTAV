function Global.CreateMissionTrain(variation, x, y, z, direction)
	return _in(0x63C6CCA8E68AE8C8, variation, x, y, z, direction, _r, _ri)
end
