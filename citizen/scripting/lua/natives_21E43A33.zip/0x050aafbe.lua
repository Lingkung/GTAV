function Global.SetPedChanceOfFiringBlanks(weaponHash, xBias, yBias)
	return _in(0x8378627201D5497D, _ch(weaponHash), xBias, yBias)
end
