function Global.SetBalanceAddMachine()
	return _in(0x815E5E3073DA1D67, _i, _i, _r)
end
