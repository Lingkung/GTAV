function Global.N_0xff266d1d0eb1195d()
	return _in(0xFF266D1D0EB1195D)
end
