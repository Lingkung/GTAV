function Global.ClearFocus()
	return _in(0x31B73D1EA9F01DA2)
end
