function Global.RemoveVehiclesFromGeneratorsInArea(x1, y1, z1, x2, y2, z2)
	return _in(0x46A1E1A299EC4BBA, x1, y1, z1, x2, y2, z2)
end
