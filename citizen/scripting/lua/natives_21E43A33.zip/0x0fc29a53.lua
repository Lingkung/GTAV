function Global.N_0x2b4cdca6f07ff3da(p0, p1, p2, p3, p4)
	return _in(0x2B4CDCA6F07FF3DA, p0, p1, p2, p3, _ii(p4) --[[ may be optional ]], _r, _ri)
end
