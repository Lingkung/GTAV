function Global.NetworkSetEntityCanBlend(p0, toggle)
	return _in(0xD830567D88A1E873, p0, toggle)
end
