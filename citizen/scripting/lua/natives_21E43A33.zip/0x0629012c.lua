function Global.LeaderboardsCacheDataRow(p0)
	return _in(0xB9BB18E2C40142ED, _ii(p0) --[[ may be optional ]], _r)
end
