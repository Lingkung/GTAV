function Global.RollUpWindow(vehicle, windowIndex)
	return _in(0x602E548F46E24D59, vehicle, windowIndex, _r, _ri)
end
