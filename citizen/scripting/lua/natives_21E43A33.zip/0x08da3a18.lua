function Global.N_0x0a60017f841a54f2(p0, p1, p2, p3)
	return _in(0x0A60017F841A54F2, p0, p1, p2, p3)
end
