function Global.DisableControlAction(index, control, disable)
	return _in(0xFE99B66D079CF6BC, index, control, disable)
end
