function Global.TriggerMusicEvent(eventName)
	return _in(0x706D57B0F50DA710, _ts(eventName), _r)
end
