function Global.N_0x5f43d83fd6738741()
	return _in(0x5F43D83FD6738741, _r, _ri)
end
