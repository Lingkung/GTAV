function Global.N_0xe058175f8eafe79a(p0)
	return _in(0xE058175F8EAFE79A, p0)
end
