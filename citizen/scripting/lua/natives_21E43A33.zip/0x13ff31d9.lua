function Global.ClearFacialIdleAnimOverride(p0)
	return _in(0x726256CC1EEB182F, p0)
end
