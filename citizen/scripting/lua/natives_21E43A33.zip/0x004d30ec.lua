--- Injects a 'mouse move' event for a DUI object. Coordinates are in browser space.
-- @param duiObject The DUI browser handle.
-- @param x The mouse X position.
-- @param y The mouse Y position.
function Global.SendDuiMouseMove(duiObject, x, y)
	return _in(0xd9d7a0aa, duiObject, x, y)
end
