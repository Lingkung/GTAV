function Global.N_0xbf371cd2b64212fd(p0)
	return _in(0xBF371CD2B64212FD, p0)
end
