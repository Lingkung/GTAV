function Global.ClearReplayStats()
	return _in(0x1B1AB132A16FDA55)
end
