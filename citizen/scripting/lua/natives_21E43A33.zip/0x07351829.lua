function Global.N_0x0b568201dd99f0eb(p0)
	return _in(0x0B568201DD99F0EB, p0)
end
