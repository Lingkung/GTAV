function Global.NetworkAcceptPresenceInvite(p0)
	return _in(0xFA91550DF9318B22, p0, _r)
end
