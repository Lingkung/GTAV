function Global.N_0x61767f73eaceed21(p0)
	return _in(0x61767F73EACEED21, p0, _r)
end
