function Global.N_0x192547247864dfdd(vehicle, p1)
	return _in(0x192547247864DFDD, vehicle, p1)
end
