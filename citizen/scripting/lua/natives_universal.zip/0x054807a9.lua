function Global.HideHudComponentThisFrame(id)
	return _in(0x6806C51AD12B83B8, id)
end
