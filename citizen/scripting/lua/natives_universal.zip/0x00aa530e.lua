--- Sets the ajar angle of a door.
-- Ranges from -1.0 to 1.0, and 0.0 is closed / default.
-- p2 is always 0, p3 is always 1.
function Global.N_0xb6e6fba95c7324ac(doorHash, ajar, p2, p3)
	return _in(0xB6E6FBA95C7324AC, _ch(doorHash), ajar, p2, p3)
end
