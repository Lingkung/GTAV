--- Enables Night Vision.
-- Example:
-- C#: Function.Call(Hash.SET_NIGHTVISION, true);
-- C++: GRAPHICS::SET_NIGHTVISION(true);
-- BOOL toggle:
-- true = turns night vision on for your player.
-- false = turns night vision off for your player.
function Global.SetNightvision(toggle)
	return _in(0x18F621F7A5B1F85D, toggle)
end
