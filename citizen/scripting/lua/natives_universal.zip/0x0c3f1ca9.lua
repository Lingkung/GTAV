--- changed any --> hash
-- progress_or_time --> percentWeather2, is not time but percent of the 2nd weather (0-1).
-- weatherType1 is same as GAMEPLAY::GET_PREV_WEATHER_TYPE_HASH_NAME()
-- and weatherType 2 GAMEPLAY::GET_NEXT_WEATHER_TYPE_HASH_NAME()
-- -QuantFC
function Global.GetWeatherTypeTransition()
	return _in(0xF3BBE884A14BB413, _i, _i, _f)
end
