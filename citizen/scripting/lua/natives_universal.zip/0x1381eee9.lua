--- Note according to IDA TU27 X360(Console),
-- This native & 'NETWORK_IS_PARTY_MEMBER' both jump to the same location.
-- Side note: This location just stops where it's at once jumped to.
-- Screenshot for side note,
-- h t t p ://i.imgur.com/m2ci1mF.png
-- h t t p://i.imgur.com/Z0Wx2B6.png
function Global.NetworkIsPartyMember(networkHandle)
	return _in(0x676ED266AADD31E0, _ii(networkHandle) --[[ may be optional ]], _r)
end
