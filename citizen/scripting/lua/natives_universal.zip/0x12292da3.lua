--- Returns true if the coords are colliding with the outdoors, and false if they collide with an interior.
function Global.N_0xeea5ac2eda7c33e8(x, y, z)
	return _in(0xEEA5AC2EDA7C33E8, x, y, z, _r)
end
