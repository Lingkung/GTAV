--- List of component/props ID
-- gtaxscripting.blogspot.com/2016/04/gta-v-peds-component-and-props.html
function Global.SetPedHelmetPropIndex(ped, propIndex)
	return _in(0x26D83693ED99291C, ped, propIndex)
end
