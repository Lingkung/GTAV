function Global.N_0x1398582b7f72b3ed(p0)
	return _in(0x1398582B7F72B3ED, p0)
end
