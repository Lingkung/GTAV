--- Audio List
-- gtaforums.com/topic/795622-audio-for-mods/
-- All found occurrences in b617d, sorted alphabetically and identical lines removed: pastebin.com/FTeAj4yZ
-- Yes
function Global.SetAmbientVoiceName(ped, name)
	return _in(0x6C8065A3B780185B, ped, _ts(name))
end
