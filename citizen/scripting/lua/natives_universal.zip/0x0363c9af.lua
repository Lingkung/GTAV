--- GET_VEHICLE_MODEL_*
-- called if the vehicle is a boat -- returns vecMoveResistanceX?
-- For a full list, see here: pastebin.com/Pyb2RhZ9
function Global.N_0x5aa3f878a178c4fc(modelHash)
	return _in(0x5AA3F878A178C4FC, _ch(modelHash), _r, _rf)
end
