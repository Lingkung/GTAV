function Global.ResetPedInVehicleContext(ped)
	return _in(0x22EF8FF8778030EB, ped)
end
