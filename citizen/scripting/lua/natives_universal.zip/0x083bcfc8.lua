--- From the b678d decompiled scripts:
-- GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL("FM_Mission_Controler");
-- GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL("scr_apartment_mp");
-- GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL("scr_indep_fireworks");
-- GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL("scr_mp_cig_plane");
-- GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL("scr_mp_creator");
-- GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL("scr_ornate_heist");
-- GRAPHICS::_SET_PTFX_ASSET_NEXT_CALL("scr_prison_break_heist_station");
function Global.SetPtfxAssetNextCall(name)
	return _in(0x6C38AF3693A69A91, _ts(name))
end
