--- p1 was always -1.
-- used for phone applications; scaleform
function Global.AddTextComponentAppTitle(p0, p1)
	return _in(0x761B77454205A61D, _ts(p0), p1)
end
