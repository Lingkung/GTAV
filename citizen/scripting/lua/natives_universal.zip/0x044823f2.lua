--- Sets the camera pitch.
-- Parameters:
-- x = pitches the camera on the x axis.
-- Value2 = always seems to be hex 0x3F800000 (1.000000 float).
function Global.SetGameplayCamRelativePitch(x, Value2)
	return _in(0x6D0858B8EDFD2B7D, x, Value2)
end
