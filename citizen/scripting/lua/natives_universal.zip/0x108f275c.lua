--- BLR the shit.
function Global.NetworkSessionSetMaxPlayers(playerType, playerCount)
	return _in(0x8B6A4DD0AF9CE215, playerType, playerCount)
end
