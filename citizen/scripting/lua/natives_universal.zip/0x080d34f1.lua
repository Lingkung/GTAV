--- From the scripts:
-- PED::SET_PED_GESTURE_GROUP(PLAYER::PLAYER_PED_ID(),
-- "ANIM_GROUP_GESTURE_MISS_FRA0");
-- PED::SET_PED_GESTURE_GROUP(PLAYER::PLAYER_PED_ID(),
-- "ANIM_GROUP_GESTURE_MISS_DocksSetup1");
function Global.SetPedGestureGroup(ped, animGroupGesture)
	return _in(0xDDF803377F94AAA8, ped, _ts(animGroupGesture))
end
