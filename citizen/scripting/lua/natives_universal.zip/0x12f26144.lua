--- if "flag" is true, the AI blip will always be displayed for the specified ped, if it has an AI blip
-- If "flag" is false, the AI blip will only be displayed when the player is in combat with the specified ped, if it has an AI blip
function Global.IsAiBlipAlwaysShown(ped, flag)
	return _in(0x0C4BBF625CA98C4E, ped, flag)
end
