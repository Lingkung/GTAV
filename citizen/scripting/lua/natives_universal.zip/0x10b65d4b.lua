function Global.N_0x55df6db45179236e()
	return _in(0x55DF6DB45179236E)
end
