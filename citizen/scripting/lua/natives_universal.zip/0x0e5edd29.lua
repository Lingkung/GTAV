function Global.NetworkSpentHireMercenary(p0, p1, p2)
	return _in(0xE7B80E2BF9D80BD6, p0, p1, p2)
end
