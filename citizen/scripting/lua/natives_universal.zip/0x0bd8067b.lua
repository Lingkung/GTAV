--- The following weatherTypes are used in the scripts:
-- "CLEAR"
-- "EXTRASUNNY"
-- "CLOUDS"
-- "OVERCAST"
-- "RAIN"
-- "CLEARING"
-- "THUNDER"
-- "SMOG"
-- "FOGGY"
-- "XMAS"
-- "SNOWLIGHT"
-- "BLIZZARD"
function Global.SetWeatherTypeNowPersist(weatherType)
	return _in(0xED712CA327900C8A, _ts(weatherType))
end
