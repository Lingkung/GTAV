--- Disables the vehicle from being repaired when a vehicle extra is enabled.
-- @param vehicle The vehicle to set disable auto vehicle repair.
-- @param value Setting the value to  true prevents the vehicle from being repaired when a extra is enabled. Setting the value to false allows the vehicle from being repaired when a extra is enabled.
function Global.SetVehicleAutoRepairDisabled(vehicle, value)
	return _in(0x5f3a3574, vehicle, value)
end
