--- Gets a value indicating whether this ped's health is below its injured threshold.
-- The default threshold is 100.
function Global.IsPedInjured(ped)
	return _in(0x84A2DD9AC37C35C1, ped, _r)
end
