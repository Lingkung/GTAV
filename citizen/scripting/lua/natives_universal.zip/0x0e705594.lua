--- Dr. Underscore (1/6/18):
-- Seems to return a value 0-2.
function Global.N_0x0c0c4e81e1ac60a0()
	return _in(0x0C0C4E81E1AC60A0, _r, _ri)
end
