function Global.N_0xa306f470d1660581()
	return _in(0xA306F470D1660581, _r, _ri)
end
