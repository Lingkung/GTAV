--- Gets a destructible object's handle
-- Example:
-- OBJECT::_B48FCED898292E52(-809.9619750976562, 170.919, 75.7406997680664, 3.0, "des_tvsmash");
-- All found arguments for p4 starts with "des_" like "DES_FIB_Floor" and "des_shipsink".
function Global.GetDesObject(x, y, z, rotation, name)
	return _in(0xB48FCED898292E52, x, y, z, rotation, _ts(name), _r, _ri)
end
