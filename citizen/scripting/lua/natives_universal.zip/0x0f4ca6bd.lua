function Global.N_0xcf1182f682f65307(p0, p1)
	return _in(0xCF1182F682F65307, p0, p1)
end
