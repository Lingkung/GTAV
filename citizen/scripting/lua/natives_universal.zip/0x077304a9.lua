--- I see this as a native that would of been used back in GTA III when you finally unlocked the bridge to the next island and such.
function Global.UnlockMissionNewsStory(newsStory)
	return _in(0xB165AB7C248B2DC1, newsStory)
end
