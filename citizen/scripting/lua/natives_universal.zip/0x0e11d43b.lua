function Global.N_0x1280804f7cfd2d6c(p0)
	return _in(0x1280804F7CFD2D6C, p0)
end
