function Global.N_0x5d517b27cf6ecd04(p0)
	return _in(0x5D517B27CF6ECD04, p0)
end
