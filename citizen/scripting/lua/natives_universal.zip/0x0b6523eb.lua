function Global.N_0xcd67ad041a394c9c(p0)
	return _in(0xCD67AD041A394C9C, p0, _r, _s)
end
