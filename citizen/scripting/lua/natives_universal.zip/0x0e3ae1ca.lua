--- nothin doin.
-- void message()
-- {
-- _BEGIN_TEXT_COMMAND_OBJECTIVE("AHT_RTIT");
-- _END_TEXT_COMMAND_OBJECTIVE(0);
-- }
function Global.BeginTextCommandObjective(p0)
	return _in(0x23D69E0465570028, _ts(p0))
end
