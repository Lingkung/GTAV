function Global.NetworkHasControlOfPickup(pickup)
	return _in(0x5BC9495F0B3B6FA6, pickup, _r)
end
