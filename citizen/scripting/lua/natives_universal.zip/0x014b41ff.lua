function Global.SuppressAgitationEventsNextFrame()
	return _in(0x5F3B7749C112D552)
end
