--- Gets the amount of bombs that this vehicle has. As far as I know, this does _not_ impact vehicle weapons or the ammo of those weapons in any way, it is just a way to keep track of the amount of bombs in a specific plane.
-- In decompiled scripts this is used to check if the vehicle has enough bombs before a bomb can be dropped (bombs are dropped by using [`_SHOOT_SINGLE_BULLET_BETWEEN_COORDS_WITH_EXTRA_PARAMS`](#_0xBFE5756E7407064A)).
-- Use [`_SET_AIRCRAFT_BOMB_COUNT`](#_0xF4B2ED59DEB5D774) to set the amount of bombs on that vehicle.
-- @param aircraft The vehicle to get the amount of bombs from.
-- @return An int indicating the amount of bombs remaining on that plane.
function Global.N_0xea12bd130d7569a1(aircraft)
	return _in(0xEA12BD130D7569A1, aircraft, _r, _ri)
end
