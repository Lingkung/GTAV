function Global.ObjectValueGetArray(key)
	return _in(0x7A983AA9DA2659ED, _i, _ts(key), _r, _ri)
end
