function Global.N_0xd68a5ff8a3a89874(r, g, b, a)
	return _in(0xD68A5FF8A3A89874, r, g, b, a)
end
