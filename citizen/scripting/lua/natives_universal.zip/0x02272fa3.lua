function Global.SetMpGamerTagColor(headDisplayId, username, pointedClanTag, isRockstarClan, clanTag, p5, r, g, b)
	return _in(0x6DD05E9D83EFA4C9, headDisplayId, _ts(username), pointedClanTag, isRockstarClan, _ts(clanTag), p5, r, g, b)
end
