--- eventGroup: 0 = CEventGroupScriptAI, 1 = CEventGroupScriptNetwork
function Global.GetEventExists(eventGroup, eventIndex)
	return _in(0x936E6168A9BCEDB5, eventGroup, eventIndex, _r)
end
